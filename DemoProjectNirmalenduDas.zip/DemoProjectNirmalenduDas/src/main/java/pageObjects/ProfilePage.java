package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProfilePage {
	WebDriver driver;
	By headername = By.xpath("//*[@class='profile main']/header/h1");
	By visibleusername = By.xpath("//div[@class='profile-gravatar is-in-sidebar']/h2");
	By firstname = By.xpath("//input[@id='first_name']");
	By lastname = By.xpath("//input[@id='last_name']");
	By displayname = By.xpath("//input[@id='display_name']");
	By aboutme = By.xpath("//textarea[@id='description']");
	By hideprofiletoggle = By.xpath("//span[@class='components-form-toggle']/input");
	By labeltext = By.xpath("//label[@class='components-toggle-control__label']");
	By saveprofilebutton = By.xpath("//button[contains(text(), 'Save profile')]");
	By savedsuccessmessage = By.xpath("//div[@id='notices']/div/span[2]/span");
	By togglebuttonstatus = By.xpath("//span[contains(@class, 'components-form-toggle')]");
	By togglebuttoninput = By.xpath("//span/input[@class='components-form-toggle__input']");
	By addlinkbutton = By.xpath("//button[@class='button is-compact']");
	By cancelbutton = By.xpath("//button[contains(text(), 'Cancel')]");
	By addwordpressurlbutton = By.xpath("//div[@role='tooltip']/div[2]/div/button[1]");
	By addurlbutton = By.xpath("//div[@role='tooltip']/div[2]/div/button[2]");
	By addsitebutton = By.xpath("//form[@class='profile-links-add-other']/fieldset/button[1]");
	By logout = By.xpath("//button[@title='Log out of WordPress.com']");
	By enterurl = By.xpath("//fieldset[@class='profile-links-add-other__fieldset form-fieldset']/input[1]");
	By entersitedescription = By.xpath("//fieldset[@class='profile-links-add-other__fieldset form-fieldset']/input[2]");

	public ProfilePage(WebDriver driver) {

		this.driver = driver;
	}

	public WebElement getHeadername() {
		return driver.findElement(headername);

	}

	public WebElement getVisibleusername() {
		return driver.findElement(visibleusername);

	}

	public WebElement getFirstname() {
		return driver.findElement(firstname);
	}

	public WebElement getLastName() {
		return driver.findElement(lastname);

	}

	public WebElement getDisplayname() {
		return driver.findElement(displayname);
	}

	public WebElement getAboutme() {
		return driver.findElement(aboutme);
	}

	public WebElement getHideProfieToggle() {
		return driver.findElement(hideprofiletoggle);
	}

	public WebElement getLabelText() {
		return driver.findElement(labeltext);
	}

	public WebElement getProfileButton() {
		return driver.findElement(saveprofilebutton);
	}

	public WebElement getSaveSuccessMessage() {
		return driver.findElement(savedsuccessmessage);
	}

	public String getToggleButtonStatus() {
		return driver.findElement(togglebuttonstatus).getAttribute("class");
	}

	public WebElement toggleButtonInput() {
		return driver.findElement(togglebuttoninput);
	}

	public WebElement AddLinkButton() {
		return driver.findElement(addlinkbutton);
	}

	public WebElement CancelButton() {
		return driver.findElement(cancelbutton);
	}

	public WebElement addUrlButton() {
		WebDriverWait wait = new WebDriverWait(driver, 10);

		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(addurlbutton));
		return element;
	}

	public WebElement addwordpressurlButton() {

		WebDriverWait wait = new WebDriverWait(driver, 10);

		WebElement element2 = wait.until(ExpectedConditions.elementToBeClickable(addwordpressurlbutton));
		return element2;
	}

	public WebElement getEnterURLField() {
		return driver.findElement(enterurl);

	}

	public WebElement getEnterSiteDescription() {
		return driver.findElement(entersitedescription);

	}

	public WebElement getAddSiteButton() {
		return driver.findElement(addsitebutton);
	}

	public WebElement getLogOutbutton() {
		return driver.findElement(logout);
	}

	public void quitDriver() {
		driver.quit();
	}
}
